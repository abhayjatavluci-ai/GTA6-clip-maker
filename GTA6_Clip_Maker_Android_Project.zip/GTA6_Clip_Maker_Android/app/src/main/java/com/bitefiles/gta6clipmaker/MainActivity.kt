package com.bitefiles.gta6clipmaker

import android.app.Activity
import android.content.Intent
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.media.MediaMuxer
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.*
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.util.Locale
import kotlin.concurrent.thread
import kotlin.math.abs

class MainActivity : Activity() {
    private val pickCode = 41
    private var selectedUri: Uri? = null
    private lateinit var status: TextView
    private lateinit var progress: ProgressBar
    private lateinit var chooseButton: Button
    private lateinit var createButton: Button
    private lateinit var clipCount: Spinner
    private val main = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    private fun buildUi() {
        val bg = 0xFF101522.toInt()
        val yellow = 0xFFFFD43B.toInt()
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 32, 24, 24)
            setBackgroundColor(bg)
        }
        val title = TextView(this).apply {
            text = "GTA 6 CLIP MAKER"
            textSize = 25f
            setTextColor(yellow)
            gravity = Gravity.CENTER
        }
        val sub = TextView(this).apply {
            text = "Automatic gameplay clip finder"
            textSize = 14f
            setTextColor(0xFFE0E4EC.toInt())
            gravity = Gravity.CENTER
        }
        chooseButton = Button(this).apply {
            text = "1. SELECT VIDEO"
            setOnClickListener { pickVideo() }
        }
        val countLabel = TextView(this).apply {
            text = "Number of clips to create"
            setTextColor(-1)
            textSize = 15f
            setPadding(0, 18, 0, 4)
        }
        clipCount = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                listOf("3 clips", "5 clips", "8 clips", "10 clips"))
        }
        createButton = Button(this).apply {
            text = "2. FIND MOMENTS & CREATE CLIPS"
            isEnabled = false
            setOnClickListener { createClips() }
        }
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            visibility = View.GONE
            isIndeterminate = true
        }
        status = TextView(this).apply {
            text = "Choose a video file saved on your phone."
            setTextColor(0xFFE0E4EC.toInt())
            textSize = 14f
            setPadding(0, 20, 0, 12)
        }
        val note = TextView(this).apply {
            text = "V1: detects visually changing/action-heavy moments and exports short MP4 segments. Use only videos you own or have permission to edit. Captions, sound effects and true game-event AI are planned for later versions."
            setTextColor(0xFFADB6C8.toInt())
            textSize = 12f
            setPadding(0, 16, 0, 0)
        }
        layout.addView(title)
        layout.addView(sub)
        layout.addView(chooseButton, params())
        layout.addView(countLabel)
        layout.addView(clipCount)
        layout.addView(createButton, params())
        layout.addView(progress, params())
        layout.addView(status)
        layout.addView(note)
        setContentView(ScrollView(this).apply { addView(layout) })
    }

    private fun params() = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
    ).apply { topMargin = 18 }

    private fun pickVideo() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "video/*"
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        startActivityForResult(intent, pickCode)
    }

    @Deprecated("Legacy activity result used for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == pickCode && resultCode == Activity.RESULT_OK) {
            selectedUri = data?.data
            selectedUri?.let {
                try { contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
                status.text = "Video selected. Ready to analyze."
                createButton.isEnabled = true
            }
        }
    }

    private fun createClips() {
        val uri = selectedUri ?: return
        val count = when (clipCount.selectedItemPosition) { 0 -> 3; 1 -> 5; 2 -> 8; else -> 10 }
        createButton.isEnabled = false
        progress.visibility = View.VISIBLE
        status.text = "Analyzing video frames…"
        thread {
            try {
                val retriever = MediaMetadataRetriever()
                retriever.setDataSource(this, uri)
                val durationMs = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLong() ?: 0L
                if (durationMs < 8000) throw Exception("Video is too short.")
                val candidates = mutableListOf<Pair<Long, Double>>()
                var previous: IntArray? = null
                val sampleStep = 1000L
                var t = 1000L
                while (t < durationMs - 1000) {
                    val bmp = retriever.getFrameAtTime(t * 1000, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                    if (bmp != null) {
                        val small = android.graphics.Bitmap.createScaledBitmap(bmp, 32, 18, true)
                        val pixels = IntArray(32 * 18)
                        small.getPixels(pixels, 0, 32, 0, 0, 32, 18)
                        val old = previous
                        if (old != null) {
                            var diff = 0.0
                            for (i in pixels.indices) {
                                val a = pixels[i]; val b = old[i]
                                val la = ((a shr 16 and 255) * 0.299 + (a shr 8 and 255) * 0.587 + (a and 255) * 0.114)
                                val lb = ((b shr 16 and 255) * 0.299 + (b shr 8 and 255) * 0.587 + (b and 255) * 0.114)
                                diff += abs(la - lb)
                            }
                            candidates.add(t to (diff / pixels.size))
                        }
                        previous = pixels
                        small.recycle()
                        bmp.recycle()
                    }
                    t += sampleStep
                }
                retriever.release()
                val ranked = candidates.sortedByDescending { it.second }
                val clipLen = 25_000L
                val starts = mutableListOf<Long>()
                for ((time, _) in ranked) {
                    val start = (time - clipLen / 2).coerceAtLeast(0L).coerceAtMost(durationMs - clipLen)
                    if (starts.all { abs(it - start) > 18_000L }) starts.add(start)
                    if (starts.size >= count) break
                }
                if (starts.isEmpty()) starts.add(0L)
                val outDir = File(getExternalFilesDir(null), "GTA6_Clips").apply { mkdirs() }
                val localInput = File(cacheDir, "source_video")
                contentResolver.openInputStream(uri)?.use { input -> FileOutputStream(localInput).use { input.copyTo(it) } }
                    ?: throw Exception("Could not read selected video.")
                val finalStarts = starts.sorted()
                finalStarts.forEachIndexed { index, start ->
                    main.post { status.text = "Exporting clip ${index + 1}/${finalStarts.size}…" }
                    val end = (start + clipLen).coerceAtMost(durationMs)
                    muxSegment(localInput, File(outDir, "GTA6_Short_${index + 1}.mp4"), start * 1000, end * 1000)
                }
                val info = File(outDir, "upload_pack.txt")
                info.writeText(
                    "Suggested title: GTA 6 INSANE Gameplay Moment! #shorts\n\n" +
                    "Suggested hashtags: #GTA6 #GTAVI #GTA6Gameplay #GamingShorts #Shorts\n\n" +
                    "Note: Review every clip before posting. Add captions/music only when you have rights to use them.\n"
                )
                main.post {
                    progress.visibility = View.GONE
                    createButton.isEnabled = true
                    status.text = "Finished! ${finalStarts.size} clips saved in app storage: ${outDir.absolutePath}\nUpload title + hashtags file also created."
                    Toast.makeText(this, "Clips created!", Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                main.post {
                    progress.visibility = View.GONE
                    createButton.isEnabled = true
                    status.text = "Could not create clips: ${e.message}"
                }
            }
        }
    }

    private fun muxSegment(input: File, output: File, startUs: Long, endUs: Long) {
        val extractor = MediaExtractor()
        extractor.setDataSource(input.absolutePath)
        val muxer = MediaMuxer(output.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        val indexMap = mutableMapOf<Int, Int>()
        for (i in 0 until extractor.trackCount) {
            val format = extractor.getTrackFormat(i)
            val mime = format.getString(MediaFormat.KEY_MIME) ?: continue
            if (mime.startsWith("video/") || mime.startsWith("audio/")) {
                extractor.selectTrack(i)
                indexMap[i] = muxer.addTrack(format)
            }
        }
        if (indexMap.isEmpty()) {
            extractor.release(); muxer.release()
            throw Exception("No audio/video tracks found.")
        }
        muxer.start()
        extractor.seekTo(startUs, MediaExtractor.SEEK_TO_CLOSEST_SYNC)
        val buffer = ByteBuffer.allocate(2 * 1024 * 1024)
        val info = android.media.MediaCodec.BufferInfo()
        while (true) {
            info.offset = 0
            info.size = extractor.readSampleData(buffer, 0)
            if (info.size < 0) break
            val pts = extractor.sampleTime
            if (pts < 0 || pts > endUs) break
            val track = extractor.sampleTrackIndex
            val outTrack = indexMap[track]
            if (outTrack != null && pts >= startUs) {
                info.presentationTimeUs = pts - startUs
                info.flags = extractor.sampleFlags
                muxer.writeSampleData(outTrack, buffer, info)
            }
            if (!extractor.advance()) break
        }
        muxer.stop()
        muxer.release()
        extractor.release()
    }
}
