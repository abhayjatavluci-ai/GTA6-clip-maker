plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.bitefiles.gta6clipmaker"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.bitefiles.gta6clipmaker"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
